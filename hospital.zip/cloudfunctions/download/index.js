// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
var db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()

  return await db.collection('Hospital').where({
    mark:'未完成'
  }).get({
    success:res=>{
      return res
    }
  })
}