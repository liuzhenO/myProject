Page({
  data:{
    input:''
  },

  judgeInput:function(e){
    var input = e.detail.value
    this.setData({
      input:input
    })
  },

  judgeButton:function(){
    var value = this.data.input
    if(value == 123456){
      wx.redirectTo({
        url: '../nurse/nurse'
      })
    }
    else{
      wx.navigateBack({
        delta: 1,
      })
    }
  }
})