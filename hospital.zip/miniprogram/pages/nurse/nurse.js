const devicesId = "562214216"
const api_key = "8U9dfpYNgd0HsNHlL5vR1pqLdxU=" 

Page({
  data:{
    value:[],
    call:[]
  },
  onLoad:function(){
    const timer = setInterval(() => {
      this.bupt({
        //每六秒查看是否有病人呼叫
      })
    }, 6000)
    const timer2 = setInterval(() => {
      this.renew({
        //每六秒查看是否有新增数据
      })
    }, 6000)
  },
  button:function(e){
    var that = this
    //console.log(e.currentTarget.dataset.id)
    var id = e.currentTarget.dataset.id
    wx.cloud.callFunction({
      name: "delete",
      data: {
        _id: id,
      }
    })
    that.onLoad()
  },
  bupt:function(){
    var that = this
    var arr = this.data.call
    for(var i = 0;i < arr.length;i++){
      var mark = arr[i].mark
      var patientID = arr[i].patientID
      var id = arr[i]._id
    }
    if (mark == '呼叫') {
      wx.showModal({
        title: '提示',
        content: patientID + '号病人呼叫',
        success: function (res) {
          if (res.confirm) {
            wx.cloud.callFunction({
              name:'callDelete',
              data:{
                _id:id
              }
            })
          } else {
            console.log('弹框后点取消')
          }
        }
      })
    }
  },
  renew:function(){
    wx.cloud.init({
      traceUser: true
    })
    wx.cloud.callFunction({
      name: 'download',
      complete: res => {
        //console.log(res);
        this.setData({
          value: res.result.data
        })
      }
    })
    var _this = this
    wx.cloud.callFunction({
      name: 'callDownload',
      complete: res => {
        //console.log(res)
        _this.setData({
          call: res.result.data
        })
      }
    })
  }
})