const devicesId = "562214216"
const api_key = "8U9dfpYNgd0HsNHlL5vR1pqLdxU=" 

Page({
  data: {
    t_length: 0,
    patientID:'',
    number:'',
    text:'',
    mark:'未完成'
  },

  bindText: function (e) {
    var t_text = e.detail.value.length;
    var text = e.detail.value;
    this.setData({
      t_length: t_text,
      text:text
    })
  },

   patientID:function(e){
    var patientID = e.detail.value;
    this.setData({
      patientID:patientID
    })
  } ,

  number:function(e){
    var number = e.detail.value;
    this.setData({
      number:number
    })
  },

  patientSubmit:function(){
    var number = this.data.number
    var patientID = this.data.patientID
    var text = this.data.text
    var t_length = this.data.t_length
    var mark = this.data.mark
    wx.redirectTo({
      url: '../paitent/paitent?number=' + number + '&patientID=' + patientID + '&text=' + text + '&t_length=' + t_length
    })
    var _this = this;
    wx.cloud.callFunction({
      name: 'upload',
      data: {
        patientID:patientID,
        number:number,
        text:text,
        mark:mark
      },success:res=>{
        console.log(res)
      },
      fail:err=>{
        console.log(err)
      }
    })
  }
})