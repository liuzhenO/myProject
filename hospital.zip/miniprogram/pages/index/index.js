Page({
  data:{

  },

  nurse:function(){
    wx.navigateTo({
      url: '../judge/judge'
    })
  },

  patient:function(){
    wx.navigateTo({
      url:'../patientMessage/patientMessage'
    })
  }
})