const devicesId = "562214216"
const api_key = "8U9dfpYNgd0HsNHlL5vR1pqLdxU=" 

Page({
  data:{
    number :'',
    patientID:'',
    text:'无备注...',
    liquid:[],
    mark:'呼叫'
  },

  onLoad: function (options) {
    var _this = this;
    var number = options.number;
    var patientID = options.patientID;
    var text = options.text;
    var t_length = options.t_length;
    this.setData({
      number:number,
      patientID:patientID
    })
    if(t_length > 0){
      this.setData({
        text:text
      })
    }
    console.log(devicesId);// 打印设备ID
    console.log(api_key);// 打印API_KEY
    //每隔6s自动获取一次数据进行更新
    const timer = setInterval(() => {
      this.getDatapoints().then(datapoints => {

      })
    }, 1500)

    wx.showLoading({
      title: '加载中'
    })

    this.getDatapoints().then((datapoints) => {
      wx.hideLoading()
    }).catch((err) => {
      wx.hideLoading()
      console.error(err)
      clearInterval(timer) 
    })
  },
  getDatapoints: function () {
    return new Promise((resolve, reject) => {
      wx.request({
        url: `https://api.heclouds.com/devices/${devicesId}/datapoints?datastream_id=level1&limit=1`,
        header: {
          'content-type': 'application/json',
          'api-key': api_key
        },
        success: (res) => {
          const status = res.statusCode
          const response = res.data
          //console.log(response)
          this.setData({
           liquid:response.data.datastreams[0].datapoints
          })
          if (status !== 200) { 
            reject(res.data)
            return;
          }
          if (response.errno !== 0) { 
            reject(response.error)
            return;
          }

          if (response.data.datastreams.length === 0) {
            reject("当前设备无数据, 请先运行硬件实验")
          }
          resolve({
            
          })
        },
        fail: (err) => {
          reject(err)
        }
      })
    })
  },

  call:function(){
    var mark = this.data.mark
    var patientID = this.data.patientID
    wx.cloud.callFunction({
      name:'upload',
      data:{
        mark:mark,
        patientID:patientID,
      }
    })
  }
})